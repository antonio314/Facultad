#!/usr/bin/env python 
# -*- coding: utf-8 -*-
 
import os, sys
import pygame
from pygame.locals import *

import MySQLdb


if not pygame.font: print 'estilos y letras desactivadas!'
if not pygame.mixer: print 'sonidos desactivados!'
 
WIDTH = 510
HEIGHT = 452
PUNTUACION = 0


puntuacion = 0

#Funcion que carga un fondo de pantalla
def carga_fondo(name, colorkey=None):

	fullname = os.path.join('img', name)

	try:
		image = pygame.image.load(fullname)

	except pygame.error, message:

		print 'No se puede cargar la imagen:', name

		raise SystemExit, message

	image = image.convert()

	return image


#Funcion que carga un sprite estatico
def carga_imagen(name, colorkey=None):

	fullname = os.path.join('img', name)

	try:

		image = pygame.image.load(fullname)

	except pygame.error, message:

		print 'No se puede cargar la imagen:', name
		raise SystemExit, message

	image = image.convert()

	if colorkey is not None:

		if colorkey is -1:

			colorkey = image.get_at((0,0))

		image.set_colorkey(colorkey, RLEACCEL)

	return image


#Funcion qeu divide un sprite dinamico
def divide_imagen(image, rect):

	subimage = image.subsurface(rect)

	return subimage, rect
 

class Seta(pygame.sprite.Sprite):

	def __init__(self):

		pygame.sprite.Sprite.__init__(self)
		self.image = carga_imagen("seta.png",-1)
		self.imagenes = [2,2,2,2,2,2,2,2,2,10,2,2,2,2,2,2,2,2,2,20]
		self.imagenes[0] = carga_imagen("seta1.png",-1)
		self.imagenes[1] = carga_imagen("seta2.png",-1)
		self.imagenes[2] = carga_imagen("seta3.png",-1)
		self.imagenes[3] = carga_imagen("seta4.png",-1)
		self.imagenes[4] = carga_imagen("seta5.png",-1)
		self.imagenes[5] = carga_imagen("seta6.png",-1)
		self.imagenes[6] = carga_imagen("seta7.png",-1)
		self.imagenes[7] = carga_imagen("seta8.png",-1)
		self.imagenes[8] = carga_imagen("seta9.png",-1)

		self.rect = self.image.get_rect()
		self.rect.centerx = 478
		self.rect.centery = 392
		self.speed = -0.08
		self.contador = 0;
		self.velocidad = 20
 
	def actualizar(self, time, tubo1, tubo2, mario, tortuga):

		self.rect.centerx += self.speed * time

		self.velocidad = (self.velocidad + 1) % 2

		if (self.velocidad) == 0:

			self.contador = (self.contador + 1) % 9

			self.image = self.imagenes[self.contador]

			if self.speed > 0:

				self.image = pygame.transform.flip(self.image,1,0)
		
		if pygame.sprite.collide_rect(self, tubo2) and self.speed < 0: 

			self.speed = -self.speed
			
		if pygame.sprite.collide_rect(self, tubo1) and self.speed > 0:

			self.speed = -self.speed

		if pygame.sprite.collide_rect(self, tortuga):

			self.speed = -self.speed

		if pygame.sprite.collide_rect(self, mario):

			return 1			
		
		return 0



class Tortuga(pygame.sprite.Sprite):

	def __init__(self):

		pygame.sprite.Sprite.__init__(self)
		self.image = carga_imagen("tortuga.png",-1)
		self.imagenes = [2,2,2,2,2,2,2,2,2,10,2,2,2,2,2,2,2,2,2,20]
		self.imagenes[0] = carga_imagen("tortuga1.png",-1)
		self.imagenes[1] = carga_imagen("tortuga2.png",-1)
		self.imagenes[2] = carga_imagen("tortuga3.png",-1)
		self.imagenes[3] = carga_imagen("tortuga4.png",-1)
		self.imagenes[4] = carga_imagen("tortuga5.png",-1)
		self.imagenes[5] = carga_imagen("tortuga6.png",-1)
		self.imagenes[6] = carga_imagen("tortuga7.png",-1)
		self.imagenes[7] = carga_imagen("tortuga8.png",-1)
		self.imagenes[8] = carga_imagen("tortuga9.png",-1)
		self.imagenes[9] = carga_imagen("tortuga10.png",-1)
		self.imagenes[10] = carga_imagen("tortuga11.png",-1)
		self.imagenes[11] = carga_imagen("tortuga12.png",-1)
		self.imagenes[12] = carga_imagen("tortuga13.png",-1)
		self.imagenes[13] = carga_imagen("tortuga14.png",-1)
		self.imagenes[14] = carga_imagen("tortuga15.png",-1)
		
		self.rect = self.image.get_rect()
		self.rect.centerx = 125
		self.rect.centery = 386
		self.speed = 0.08
		self.contador = 0;
		self.velocidad = 20
 
	def actualizar(self, time, tubo1, tubo2, mario, seta):

		self.rect.centerx += self.speed * time

		self.velocidad = (self.velocidad + 1) % 2

		if (self.velocidad) == 0:

			self.contador = (self.contador + 1) % 15

			self.image = self.imagenes[self.contador]

			if self.speed > 0:

				self.image = pygame.transform.flip(self.image,1,0)
		
		if pygame.sprite.collide_rect(self, tubo2) and self.speed < 0: 

			self.speed = -self.speed
			
		if pygame.sprite.collide_rect(self, tubo1) and self.speed > 0:

			self.speed = -self.speed

		if pygame.sprite.collide_rect(self, seta):

			self.speed = -self.speed

		if pygame.sprite.collide_rect(self, mario):

			return 1			
		
		return 0



class Tubo(pygame.sprite.Sprite):

	def __init__(self,x,y):
		
		pygame.sprite.Sprite.__init__(self)
		self.image = carga_imagen("tubo.png",-1)
		self.rect = self.image.get_rect()
		self.rect.centerx = x
		self.rect.centery = y





class Moneda(pygame.sprite.Sprite):

	def __init__(self,x,y):

		pygame.sprite.Sprite.__init__(self)
		self.imagenes = [4,1,4,4]
		self.imagenes[0] = carga_imagen("moneda1.png",-1)
		self.imagenes[1] = carga_imagen("moneda2.png",-1)
		self.imagenes[2] = carga_imagen("moneda3.png",-1)
		self.imagenes[3] = carga_imagen("moneda4.png",-1)
		self.image = self.imagenes[0]
		self.rect = self.image.get_rect()
		self.rect.centerx = x
		self.rect.centery = y
		self.contador = 0;
		self.velocidad = 20
		self.puntuacion = 0

	def actualizar(self,mario):

		self.velocidad = (self.velocidad + 1) % 4

		if (self.velocidad) == 0:

			self.contador = (self.contador + 1) % 4

			self.image = self.imagenes[self.contador]

		if pygame.sprite.collide_rect(self, mario):
		
			self.rect.centerx = -5
			self.rect.centery = -5
			
			return 10

		return 0




class Mario(pygame.sprite.Sprite):

	def __init__(self):
		
		pygame.sprite.Sprite.__init__(self)
		self.imagenes = [2,2,2,2,2,2,2,2,2,10,2,2,2,2,2,2,2,2,2,20,2,2,2,2,2,2,2,2,2]
		self.imagenes[26] = carga_imagen("mariofinal.png",-1)
		self.imagenes[25] = carga_imagen("mariosalta.png",-1)
		self.imagenes[24] = carga_imagen("marioparado.png",-1)
		self.imagenes[0] = carga_imagen("mario1.png",-1)
		self.imagenes[1] = carga_imagen("mario2.png",-1)
		self.imagenes[2] = carga_imagen("mario3.png",-1)
		self.imagenes[3] = carga_imagen("mario4.png",-1)
		self.imagenes[4] = carga_imagen("mario5.png",-1)
		self.imagenes[5] = carga_imagen("mario6.png",-1)
		self.imagenes[6] = carga_imagen("mario7.png",-1)
		self.imagenes[7] = carga_imagen("mario8.png",-1)
		self.imagenes[8] = carga_imagen("mario9.png",-1)
		self.imagenes[9] = carga_imagen("mario10.png",-1)
		self.imagenes[10] = carga_imagen("mario11.png",-1)
		self.imagenes[11] = carga_imagen("mario12.png",-1)
		self.imagenes[12] = carga_imagen("mario13.png",-1)
		self.imagenes[13] = carga_imagen("mario14.png",-1)
		self.imagenes[14] = carga_imagen("mario15.png",-1)
		self.imagenes[15] = carga_imagen("mario16.png",-1)
		self.imagenes[16] = carga_imagen("mario17.png",-1)
		self.imagenes[17] = carga_imagen("mario18.png",-1)
		self.imagenes[18] = carga_imagen("mario19.png",-1)
		self.imagenes[19] = carga_imagen("mario20.png",-1)
		self.imagenes[20] = carga_imagen("mario21.png",-1)
		self.imagenes[21] = carga_imagen("mario22.png",-1)
		self.imagenes[22] = carga_imagen("mario23.png",-1)
		self.imagenes[23] = carga_imagen("mario24.png",-1)
		self.image = self.imagenes[24]	
		self.rect = self.image.get_rect()
		self.rect.centerx = 300
		self.rect.centery = 384
		self.speed = 0.10
		self.speedJump = 0.2
		self.subiendo = 0
		self.bajando = 0
		self.direccion = 2
		self.cambio = 0
		self.contador = 0
		self.velocidad = 20
		self.moviendo = 0
		
		

	def mover(self, time, keys):

		if self.rect.left >= 0:
			if keys[K_LEFT]:
				self.rect.centerx -= self.speed * time
				if self.direccion == 2:
					self.direccion = 1

				if(self.subiendo == 0):
					self.image = pygame.transform.flip(self.image,1,0)

				self.velocidad = (self.velocidad + 1) % 2

				#print self.velocidad

				if (self.velocidad) == 0:

					self.contador = (self.contador + 1) % 24
					
					self.image = self.imagenes[self.contador]
					#pygame.transform.flip(self.image,1,0)
					self.moviendo = 1
					
		else:
			self.image = self.imagenes[24]	
			self.contador = 0
			self.moviendo = 0

		if self.rect.right <= WIDTH:
			if keys[K_RIGHT]:
				self.rect.centerx += self.speed * time
				if self.direccion == 1:
					self.direccion = 2

				self.velocidad = (self.velocidad + 1) % 2

				#print self.velocidad

				if (self.velocidad) == 0:

					self.contador = (self.contador + 1) % 24
					
					self.image = self.imagenes[self.contador]
					self.moviendo = 1

		else:
			self.image = self.imagenes[24]	
			self.contador = 0
			self.moviendo = 0
					

		if self.bajando != 1 and self.subiendo != 1:
			if keys[K_z]:	
				self.subiendo = 1
				
				

		if self.bajando == 1 and self.rect.bottom <=405:
			self.rect.centery += self.speedJump * time
			if self.direccion == 1:
				self.image = pygame.transform.flip(self.image,1,0)
			if self.direccion == 2:
				self.image = self.imagenes[25]
		else:
			self.bajando = 0

		if self.subiendo == 1 and self.rect.top >= 280:
			self.rect.centery -= self.speedJump * time
		else:
			self.subiendo = 0
		
		if self.rect.top <= 279:
			self.bajando = 1


	
	def actualizar(self,keys):

		if self.subiendo == 1 or self.bajando == 1:
			self.image = self.imagenes[25]

		if self.subiendo == 0 and self.bajando == 0 and self.moviendo == 0:
			self.image = self.imagenes[24]

		if self.direccion == 1:
			self.image = pygame.transform.flip(self.image,1,0)

		if self.moviendo == 1 and (not(keys[K_RIGHT]) and not(keys[K_LEFT])):
			self.moviendo = 0 

		if self.rect.top <= 285:
			self.speedJump = 0.05

		if self.rect.top >= 285:
			self.speedJump = 0.1			
			if self.bajando == 1:
				self.speedJump = 0.15
			

		if self.rect.top >= 320:
			self.speedJump = 0.15
			if self.bajando == 1:
				self.speedJump = 0.2
			

		if self.rect.top >= 350:
			self.speedJump = 0.2


	def finalizar(self):
		
		self.image = self.imagenes[26]
		self.rect.centerx = 300
		self.rect.centery = 384
	

def letra(keys,antes):

	if keys[K_a] & (str(antes) != "a"):

		return "a"
	if keys[K_b] & (str(antes) != "b"):

		return "b"
	if keys[K_c] & (str(antes) != "c"):

		return "c"
	if keys[K_d] & (str(antes) != "d"):

		return "d"
	if keys[K_e] & (str(antes) != "e"):

		return "e"
	if keys[K_f] & (str(antes) != "f"):

		return "f"
	if keys[K_g] & (str(antes) != "g"):

		return "g"
	if keys[K_h] & (str(antes) != "h"):

		return "h"
	if keys[K_i] & (str(antes) != "i"):

		return "i"
	if keys[K_j] & (str(antes) != "j"):

		return "j"
	if keys[K_k] & (str(antes) != "k"):

		return "k"
	if keys[K_l] & (str(antes) != "l"):

		return "l"
	if keys[K_m] & (str(antes) != "m"):

		return "m"
	if keys[K_n] & (str(antes) != "n"):

		return "n"
	if keys[K_o] & (str(antes) != "o"):

		return "o"
	if keys[K_p] & (str(antes) != "p"):

		return "p"
	if keys[K_q] & (str(antes) != "q"):

		return "q"
	if keys[K_r] & (str(antes) != "r"):

		return "r"
	if keys[K_s] & (str(antes) != "s"):

		return "s"
	if keys[K_t] & (str(antes) != "t"):

		return "t"
	if keys[K_u] & (str(antes) != "u"):

		return "u"
	if keys[K_v] & (str(antes) != "v"):

		return "v"
	if keys[K_w] & (str(antes) != "w"):

		return "w"
	if keys[K_x] & (str(antes) != "x"):

		return "x"
	if keys[K_y] & (str(antes) != "y"):

		return "y"
	if keys[K_z] & (str(antes) != "z"):

		return "z"


	return "0"

def main():

	print "EL JUEGO ESTA COMENZANDO...."

	screen = pygame.display.set_mode((WIDTH, HEIGHT))
	pygame.display.set_caption("Mario Bross")
	
	Conexion = MySQLdb.connect(host='localhost',user='mario',passwd='princesa',db='marioBross')

	micursor = Conexion.cursor()


	opcion = 1
	puntuacion = 0
	repetir = True

	while opcion == 1 or opcion == 2:

		if(opcion == 1):

			puntuacion = 0

			background_image = carga_fondo('fondo_mario.png')
			#bola = Bola()
			#guerrero = Guerrero(100)
			tubos = [Tubo(498,368),Tubo(0,368)]
			monedas = [Moneda(400,290),Moneda(380,290),Moneda(360,290),Moneda(340,290),Moneda(320,290),Moneda(300,290),Moneda(280,290),Moneda(260,290),Moneda(240,290),Moneda(220,290),Moneda(200,290),Moneda(180,290),Moneda(160,290),Moneda(140,290),Moneda(120,290),Moneda(100,290)]
			numMonedas = 16
			mario = Mario()
			tortuga = Tortuga()
			seta = Seta()
				 
			clock = pygame.time.Clock()
			finalizarJuego = False 
			muerte1 = 0
			muerte2 = 0

			while not(finalizarJuego):

				time = clock.tick(40)
				keys = pygame.key.get_pressed()
		
				for eventos in pygame.event.get():
					if eventos.type == QUIT:
						#print "Puntuacion: "+str(puntuacion)
						#sys.exit(0)
			 			return puntuacion
		
				if puntuacion == 160:

					print "HAS CONSEGUIDO TODAS LAS MONEDAS"
					finalizarJuego = True
					causa = 1
				
				if muerte1 == 1 or muerte2 == 1:
			
					finalizarJuego = True
					causa = 2 

				#bola.actualizar(time, guerrero)
				#guerrero.mover(time, keys)
				mario.mover(time,keys)
				mario.actualizar(keys)

				muerte1 = tortuga.actualizar(time,tubos[0],tubos[1],mario,seta)
				muerte2 = seta.actualizar(time, tubos[0], tubos[1],mario,tortuga)
		
				i = 0
				while i < 16:
					puntuacion = puntuacion + monedas[i].actualizar(mario)
					i += 1

		

				screen.blit(background_image, (0, 0))
				screen.blit(tubos[0].image,tubos[0].rect)
				screen.blit(tubos[1].image,tubos[1].rect)
				screen.blit(monedas[0].image,monedas[0].rect)
				screen.blit(monedas[1].image,monedas[1].rect)
				screen.blit(monedas[2].image,monedas[2].rect)
				screen.blit(monedas[3].image,monedas[3].rect)
				screen.blit(monedas[4].image,monedas[4].rect)
				screen.blit(monedas[5].image,monedas[5].rect)
				screen.blit(monedas[6].image,monedas[6].rect)
				screen.blit(monedas[7].image,monedas[7].rect)
				screen.blit(monedas[8].image,monedas[8].rect)
				screen.blit(monedas[9].image,monedas[9].rect)
				screen.blit(monedas[10].image,monedas[10].rect)
				screen.blit(monedas[11].image,monedas[11].rect)
				screen.blit(monedas[12].image,monedas[12].rect)
				screen.blit(monedas[13].image,monedas[13].rect)
				screen.blit(monedas[14].image,monedas[14].rect)
				screen.blit(monedas[15].image,monedas[15].rect)
				screen.blit(tortuga.image,tortuga.rect)
				screen.blit(seta.image,seta.rect)
				screen.blit(mario.image,mario.rect)
	
				#screen.blit(bola.image, bola.rect)
				#screen.blit(guerrero.image, guerrero.rect)
				pygame.display.flip()


			fuente = pygame.font.Font(None,20)

			nombre = ""

			mensaje = "Introduzca su nombre: "
			ima_msg = fuente.render(mensaje,0,color.THECOLORS["white"])
			dest = ima_msg.get_rect(center = (WIDTH/2,180))
			ima_nom = fuente.render(nombre,0,color.THECOLORS["white"])
			dest_nom = ima_nom.get_rect(center = (WIDTH/2,190))
			screen.blit(background_image, (0, 0))
			screen.blit(mario.image,mario.rect)
			screen.blit(ima_msg,dest)
			screen.blit(ima_nom,dest_nom)
			pygame.display.flip()
			
			
			num = 0
			ultimo = ""
			while not(keys[K_RETURN]) and not(keys[K_ESCAPE]) and not(keys[K_SPACE]) and num < 20:
					
				keys = pygame.key.get_pressed()
				
				leido = letra(keys,ultimo)

				if leido != "0":
					nombre = nombre + leido	
					num = num + 1;
					ultimo = leido
					mensaje = "Introduzca su nombre: "
					ima_msg = fuente.render(mensaje,0,color.THECOLORS["white"])
					dest = ima_msg.get_rect(center = (WIDTH/2,180))
					ima_nom = fuente.render(nombre,0,color.THECOLORS["white"])
					dest_nom = ima_nom.get_rect(center = (WIDTH/2,190))
					screen.blit(background_image, (0, 0))
					screen.blit(mario.image,mario.rect)
					screen.blit(ima_msg,dest)
					screen.blit(ima_nom,dest_nom)
					pygame.display.flip()
					
		
				for eventos in pygame.event.get():
					if eventos.type == QUIT:
						
						sys.exit(0)

			print nombre			

			
			identificador = 1;
			query= "INSERT INTO RankingP1 (id,Nombre,puntuacion) VALUES (\""+str(identificador)+"\",\""+nombre+"\",\""+str(puntuacion)+"\");"

			identificador = identificador + 1

			micursor.execute(query)

			mensaje1 = "Puntuacion: "+str(puntuacion)
			ima_msg1 = fuente.render(mensaje1,0,color.THECOLORS["white"])
			dest1 = ima_msg1.get_rect(center = (WIDTH/2,180))

			mensaje2 = ""

			if causa == 1: 
				mensaje2 = nombre+" ha conseguido todas las monedas"
			if causa == 2:
				mensaje2 = "Mario ha muerto, sientete culpable"
	
			ima_msg2 = fuente.render(mensaje2,0,color.THECOLORS["white"])
			dest2 = ima_msg2.get_rect(center = (WIDTH/2,150))
			
			mario.finalizar()

			mensaje_menu1 = "MENU:"
			mensaje_menu2 = "1.- Jugar Otra Vez"
			mensaje_menu3 = "2.- Ver Ranking"
			mensaje_menu4 = "salir: Para salir cierre la ventana o 'esc'"	

			ima_menu1 = fuente.render(mensaje_menu1,0,color.THECOLORS["white"])
			dest_menu1 = ima_menu1.get_rect(center = (150,230))
			ima_menu2 = fuente.render(mensaje_menu2,0,color.THECOLORS["white"])
			dest_menu2 = ima_menu2.get_rect(center = (190,260))
			ima_menu3 = fuente.render(mensaje_menu3,0,color.THECOLORS["white"])
			dest_menu3 = ima_menu3.get_rect(center = (175,290))
			ima_menu4 = fuente.render(mensaje_menu4,0,color.THECOLORS["white"])
			dest_menu4 = ima_menu4.get_rect(center = (230,330))

	
			screen.blit(background_image, (0, 0))
			screen.blit(mario.image,mario.rect)
			screen.blit(ima_msg1,dest1)
			screen.blit(ima_msg2,dest2)
			screen.blit(ima_menu1,dest_menu1)
			screen.blit(ima_menu2,dest_menu2)
			screen.blit(ima_menu3,dest_menu3)
			screen.blit(ima_menu4,dest_menu4)
			pygame.display.flip()



				
		if opcion == 2:


			mensaje2 = " Puesto      Jugador     Puntuacion: "
			mensaje1 = "RANKING TOP 5"
			fuente = pygame.font.Font(None,20)
			ima_msg2 = fuente.render(mensaje2,0,color.THECOLORS["white"])
			dest2 = ima_msg2.get_rect(center = (150,120))
			ima_msg1 = fuente.render(mensaje1,0,color.THECOLORS["white"])
			dest1 = ima_msg1.get_rect(center = (150,90))
			mario.finalizar()

			mejores = [["user1",-1],["user2",-1],["user3",-1],["user4",-1],["user5",-1]]

			query= "SELECT Nombre, puntuacion FROM RankingP1 WHERE 1;"

			micursor.execute(query)

			contador = 0

			print "lineas: "+str(micursor.rowcount)
			
			
			while (contador < micursor.rowcount) and repetir:

				registro = micursor.fetchone()
				#print registro
				cambiado = False
				if int(mejores[0][1]) < int(registro[1]) and not(cambiado):

					mejores[4][0] = mejores[3][0]
					mejores[4][1] = mejores[3][1]
					mejores[3][0] = mejores[2][0]
					mejores[3][1] = mejores[2][1]
					mejores[2][0] = mejores[1][0]
					mejores[2][1] = mejores[1][1]
					mejores[1][0] = mejores[0][0]
					mejores[1][1] = mejores[0][1]
					mejores[0][0]= registro[0]
					mejores[0][1]= registro[1]
					cambiado = True
				if int(mejores[1][1]) < int(registro[1]) and not(cambiado):
					mejores[4][0] = mejores[3][0]
					mejores[4][1] = mejores[3][1]
					mejores[3][0] = mejores[2][0]
					mejores[3][1] = mejores[2][1]
					mejores[2][0] = mejores[1][0]
					mejores[2][1] = mejores[1][1]
					mejores[1][0]= registro[0]
					mejores[1][1]= registro[1]
					cambiado = True
				if int(mejores[2][1]) < int(registro[1]) and not(cambiado):
					mejores[4][0] = mejores[3][0]
					mejores[4][1] = mejores[3][1]
					mejores[3][0] = mejores[2][0]
					mejores[3][1] = mejores[2][1]
					mejores[2][0]= registro[0]
					mejores[2][1]= registro[1]
					cambiado = True
				if int(mejores[3][1]) < int(registro[1]) and not(cambiado):
					mejores[4][0] = mejores[3][0]
					mejores[4][1] = mejores[3][1]
					mejores[3][0]= registro[0]
					mejores[3][1]= registro[1]
					cambiado = True
				if int(mejores[4][1]) < int(registro[1]) and not(cambiado):
					mejores[4][0]= registro[0]
					mejores[4][1]= registro[1]
					cambiado = True


				contador = contador + 1

				

			if repetir:

				print mejores[0][0]
				repetir = False

				mensaje_res1 = "1  " + mejores[0][0] + "  "+str(mejores[0][1])
				mensaje_res2 = "2  " + mejores[1][0] + "  "+str(mejores[1][1])
				mensaje_res3 = "3  " + mejores[2][0] + "  "+str(mejores[2][1])
				mensaje_res4 = "4  " + mejores[3][0] + "  "+str(mejores[3][1])
				mensaje_res5 = "5  " + mejores[4][0] + "  "+str(mejores[4][1])

				print mensaje_res1
				#print mansaje_res2

			ima_res1 = fuente.render(mensaje_res1,0,color.THECOLORS["white"])
			dest_res1 = ima_res1.get_rect(center = (150,140))			
			ima_res2 = fuente.render(mensaje_res2,0,color.THECOLORS["white"])
			dest_res2 = ima_res2.get_rect(center = (150,160))
			ima_res3 = fuente.render(mensaje_res3,0,color.THECOLORS["white"])
			dest_res3 = ima_res3.get_rect(center = (150,180))			
			ima_res4 = fuente.render(mensaje_res4,0,color.THECOLORS["white"])
			dest_res4 = ima_res4.get_rect(center = (150,200))
			ima_res5 = fuente.render(mensaje_res5,0,color.THECOLORS["white"])
			dest_res5 = ima_res5.get_rect(center = (150,220))
			



			mensaje_menu1 = "MENU:"
			mensaje_menu2 = "1.- Jugar Otra Vez"
			mensaje_menu3 = "2.- Ver Ranking"
			mensaje_menu4 = "salir: Para salir cierre la ventana o 'esc'"	

			ima_menu1 = fuente.render(mensaje_menu1,0,color.THECOLORS["white"])
			dest_menu1 = ima_menu1.get_rect(center = (290,230))
			ima_menu2 = fuente.render(mensaje_menu2,0,color.THECOLORS["white"])
			dest_menu2 = ima_menu2.get_rect(center = (325,260))
			ima_menu3 = fuente.render(mensaje_menu3,0,color.THECOLORS["white"])
			dest_menu3 = ima_menu3.get_rect(center = (325,290))
			ima_menu4 = fuente.render(mensaje_menu4,0,color.THECOLORS["white"])
			dest_menu4 = ima_menu4.get_rect(center = (370,330))

	
			screen.blit(background_image, (0, 0))
			screen.blit(mario.image,mario.rect)
			screen.blit(ima_msg1,dest1)
			screen.blit(ima_msg2,dest2)
			screen.blit(ima_res1,dest_res1)
			screen.blit(ima_res2,dest_res2)
			screen.blit(ima_res3,dest_res3)
			screen.blit(ima_res4,dest_res4)
			screen.blit(ima_res5,dest_res5)
			screen.blit(ima_menu1,dest_menu1)
			screen.blit(ima_menu2,dest_menu2)
			screen.blit(ima_menu3,dest_menu3)
			screen.blit(ima_menu4,dest_menu4)
			pygame.display.flip()

		salir = False

		while not salir:
			for eventos in pygame.event.get():
				if eventos.type == QUIT:
					salir = True
					opcion = 0
					sys.exit(0)

			keys = pygame.key.get_pressed()

			if keys[K_1]: 

				opcion = 1
				salir = True

			if keys[K_2]:

				opcion = 2
				salir = True
				repetir = True

			if keys[K_ESCAPE]:

				opcion = 2
				salir = True
				sys.exit(0)

	return 0
 
if __name__ == '__main__':

	pygame.init()
	puntuacion = main()

	

	


